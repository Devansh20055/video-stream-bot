<h1 align = "center"> 🎵 Video Bot 🎵 </h1>

<p align="center"><b> Video Bot is a Music powerfull bot for playing music (Video or Audio) on telegram voice chat groups. </b></p>


<p align="center"><a href="https://t.me/marrkmusic"><img src="https://te.legra.ph/file/7bdf03c71f848170d24b9.jpg"></a></p>
<p align="center">
    <br><b>Video Bot is an Advanced Telegram Bot that's allow you to play Video & Music on Telegram Group Video Chat</b><br>
</p>
<p align="center">
    <a href="https://www.python.org/" alt="made-with-python"> <img src="https://img.shields.io/badge/Made%20with-Python-black.svg?style=flat-square&logo=python&logoColor=blue&color=red" /></a>
    <a href="https://github.com/marrk85/Music-Video/graphs/commit-activity" alt="Maintenance"> <img src="https://img.shields.io/badge/Maintained%3F-yes-red.svg?style=flat-square" /></a>
    <a href="https://app.codacy.com/gh/marrk85/Music-Video/dashboard"> <img src="https://img.shields.io/codacy/grade/a723cb464d5a4d25be3152b5d71de82d?color=red&logo=codacy&style=flat-square" alt="Codacy" /></a><br>
    <a href="https://github.com/marrk85/Music-Video"> <img src="https://img.shields.io/github/repo-size/marrk85/Music-Video?color=red&logo=github&logoColor=blue&style=flat-square" /></a>
    <a href="https://github.com/marrk85/Music-Video/commits/main"> <img src="https://img.shields.io/github/last-commit/marrk85/Music-Video?color=red&logo=github&logoColor=blue&style=flat-square" /></a>
    <a href="https://github.com/marrk85/Music-Video/issues"> <img src="https://img.shields.io/github/issues/marrk85/Music-Video?color=red&logo=github&logoColor=blue&style=flat-square" /></a>
    <a href="https://github.com/marrk85/Music-Video/network/members"> <img src="https://img.shields.io/github/forks/marrk85/Music-Video?color=red&logo=github&logoColor=blue&style=flat-square" /></a>  
    <a href="https://github.com/marrk85/Music-Video/network/members"> <img src="https://img.shields.io/github/stars/marrk85/Music-Video?color=red&logo=github&logoColor=blue&style=flat-square" /></a>  
</p>

Can be found on Telegram as [Marrk Bot ❤](https://t.me/Jmhaiabr>

### 🔎 Support Inline Search

## 📊 Stats
[![CodeFactor](https://www.codefactor.io/repository/github/Rishabhbhan4/video-Bot/badge)](https://www.codefactor.io/repository/github/marrk85/Music-Video)

## 🧪 Get `SESSION_NAME` from below:

 [![GenerateString](https://te.legra.ph/file/e63dc76bc56a39f3383ab.jpg)](https://replit.com/@marrk85/genStr#main.py)


## 🎭 Preview
<p align="center">
  <img src="https://te.legra.ph/file/56708bcb0025da5dc19c4.jpg">
</p>

## Heroku Deployment <img src="./ImageFont/Kenred.gif" width="40px">
The easy way to host this bot, deploy to Heroku.
Click On The Image To Deploy
[![Deploy](https://te.legra.ph/file/131da17a823ddcb96f2f5.jpg)](https://heroku.com/deploy?template=https://github.com/marrk85/Music-Video)

## VPS Deployment 🎵
Get the best Quality of streaming performance by hosting it on VPS, here's the step's:

```sh
sudo apt update && apt upgrade -y
sudo apt install git curl python3-pip ffmpeg -y
pip3 install -U pip
curl -sL https://deb.nodesource.com/setup_16.x | bash -
sudo apt-get install -y nodejs
npm i -g npm
git clone https://github.com/https://te.legra.ph/file/56708bcb0025da5dc19c4.jpg # clone the repo.
cd video-Bot
pip3 install -U -r requirements.txt
cp example.env .env # use vim to edit ENVs
vim .env # fill up the ENVs (Steps: press i to enter in insert mode then edit the file. Press Esc to exit the editing mode then type :wq! and press Enter key to save the file).
python3 main.py # run the bot.

# continue the host with screen or anything else, thanks for reading.
```

# Credits 💖

- [Marrk](https://github.com/marrk85) ``Dev``
- [Kaka](https//gitHub.com/kaka026) ``Dev``
- [Veez Music](https://github.com/levina-lab/veezmusic) Veez Music
------
## Telegram Support & Updates 🏢
- [![Telegram Group](https://img.shields.io/badge/Telegram-Group-brightgreen)](https://t.me/marrkmusic)
- [![Telegram Channel](https://img.shields.io/badge/Telegram-Channel-brightgreen)](https://t.me/marrkHelpBots)
